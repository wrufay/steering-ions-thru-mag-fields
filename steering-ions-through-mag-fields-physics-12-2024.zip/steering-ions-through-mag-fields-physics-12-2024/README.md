# Steering ions through mag. fields (Physics 12, 2024)

A Pen created on CodePen.

Original URL: [https://codepen.io/poha/pen/mybWYaY](https://codepen.io/poha/pen/mybWYaY).

